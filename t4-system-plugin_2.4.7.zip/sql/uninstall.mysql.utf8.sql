DROP TABLE IF EXISTS `#__t4_block`;
DROP TABLE IF EXISTS `#__t4_item`;
DROP TABLE IF EXISTS `#__t4_revision`;
DROP TABLE IF EXISTS `#__t4_tag`;
